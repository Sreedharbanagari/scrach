({
myAction : function(component, event, helper) {
var action = component.get("c.getSuggestions");
action.setCallback(this, function(data) {
component.set("v.suggestions", data.getReturnValue());
});
$A.enqueueAction(action);
	}
})