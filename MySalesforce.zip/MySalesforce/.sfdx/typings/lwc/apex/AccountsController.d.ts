declare module "@salesforce/apex/AccountsController.getAccounts" {
  export default function getAccounts(): Promise<any>;
}
