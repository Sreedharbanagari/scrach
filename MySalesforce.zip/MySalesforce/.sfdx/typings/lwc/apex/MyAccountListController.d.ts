declare module "@salesforce/apex/MyAccountListController.getSuggestions" {
  export default function getSuggestions(): Promise<any>;
}
