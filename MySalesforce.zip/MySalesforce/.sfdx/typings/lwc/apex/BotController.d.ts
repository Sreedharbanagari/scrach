declare module "@salesforce/apex/BotController.submit" {
  export default function submit(param: {utterance: any, session: any, fileName: any, fileContent: any}): Promise<any>;
}
